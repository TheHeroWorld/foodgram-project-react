from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'api.users'
    verbose_name = 'Пользователи'
