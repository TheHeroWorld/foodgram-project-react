from django.apps import AppConfig


class FoodgramConfig(AppConfig):
    name = 'apps.foodgram'
